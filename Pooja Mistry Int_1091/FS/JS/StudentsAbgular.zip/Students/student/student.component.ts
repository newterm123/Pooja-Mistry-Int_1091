import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-student',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss']
})
export class StudentComponent {

  student = {
    name: '',
    hobbies: '',
    
  };

  message: string = '';

  showReason() {
    this.message = "We come into RISE to learn skills and become a software developer.";
  }
}